# SocialBook — React + Tailwind CSS

An original, responsive social-media front-end inspired by familiar social feed layouts. It is not affiliated with Facebook or Meta.

## Features in this demo
- Responsive three-column feed layout
- Story cards and profile avatars
- Create text posts
- Like and unlike posts
- Add comments
- Search posts
- Demo friend-request buttons and navigation feedback

## Run on a computer
1. Install Node.js (LTS) from https://nodejs.org/
2. Unzip this folder and open a terminal in the project folder.
3. Run `npm install`
4. Run `npm run dev`
5. Open the local URL shown by Vite.

## Important
This is a front-end prototype. Posts are kept in browser memory and reset when the page reloads. Real accounts, secure login, image uploads, persistent posts, friend relationships, notifications, and private messaging require a backend and security rules.

## iPhone-only note
You can keep and edit these files from an iPhone using a browser-based coding workspace that supports React/Vite and npm. Upload the ZIP, open the project, then run the workspace's preview. Some hosting services may require an account or paid plan.
