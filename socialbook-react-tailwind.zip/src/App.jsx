import { useMemo, useState } from 'react'
import {
  Search, Home, Users, Video, Store, UsersRound, Bell, MessageCircle,
  Menu, Plus, Image, Smile, MoreHorizontal, ThumbsUp, MessageSquare,
  Share2, Globe2, ChevronDown, X, Send, Bookmark, CalendarDays,
  Flag, PlaySquare, Heart, Sparkles
} from 'lucide-react'

const avatar = (seed) => `https://i.pravatar.cc/100?img=${seed}`

const initialPosts = [
  {
    id: 1, name: 'Travel Vibes', avatar: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=100&h=100&fit=crop',
    time: '2h', text: 'Nothing beats a sunset by the ocean. 🌅\nGrateful for these moments and the people who make them special. 💙',
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=1200&auto=format&fit=crop&q=85',
    likes: 245, comments: 24, shares: 12, liked: false,
  },
  {
    id: 2, name: 'Jamie Parker', avatar: avatar(12), time: '4h',
    text: 'A little reminder to slow down, enjoy the small things, and make today count ✨ What are you grateful for today?',
    image: '', likes: 86, comments: 9, shares: 3, liked: false,
  },
]

const stories = [
  { name: 'Sarah Khan', image: avatar(47), cover: 'https://images.unsplash.com/photo-1519608487953-e999c86e7455?w=300&auto=format&fit=crop&q=80' },
  { name: 'Mike Johnson', image: avatar(12), cover: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=300&auto=format&fit=crop&q=80' },
  { name: 'Priya Sharma', image: avatar(44), cover: 'https://images.unsplash.com/photo-1500375592092-40eb2168fd21?w=300&auto=format&fit=crop&q=80' },
  { name: 'David Lee', image: avatar(68), cover: 'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?w=300&auto=format&fit=crop&q=80' },
]

function App() {
  const [posts, setPosts] = useState(initialPosts)
  const [draft, setDraft] = useState('')
  const [search, setSearch] = useState('')
  const [activeNav, setActiveNav] = useState('Home')
  const [notice, setNotice] = useState('')
  const [commentDrafts, setCommentDrafts] = useState({})
  const [comments, setComments] = useState({})
  const [openComments, setOpenComments] = useState({})
  const [showMore, setShowMore] = useState(false)

  const visiblePosts = useMemo(() => posts.filter(p =>
    `${p.name} ${p.text}`.toLowerCase().includes(search.toLowerCase())
  ), [posts, search])

  const publish = () => {
    if (!draft.trim()) return
    setPosts([{ id: Date.now(), name: 'Abhi Arya', avatar: avatar(13), time: 'Just now', text: draft.trim(), image: '', likes: 0, comments: 0, shares: 0, liked: false }, ...posts])
    setDraft('')
    setNotice('Your post has been published on this demo.')
    setTimeout(() => setNotice(''), 2600)
  }

  const toggleLike = (id) => setPosts(current => current.map(p =>
    p.id === id ? { ...p, liked: !p.liked, likes: p.likes + (p.liked ? -1 : 1) } : p
  ))

  const addComment = (id) => {
    const value = (commentDrafts[id] || '').trim()
    if (!value) return
    setComments(prev => ({ ...prev, [id]: [...(prev[id] || []), value] }))
    setCommentDrafts(prev => ({ ...prev, [id]: '' }))
    setPosts(prev => prev.map(p => p.id === id ? { ...p, comments: p.comments + 1 } : p))
  }

  const navItems = [
    { label: 'Home', icon: Home }, { label: 'Friends', icon: Users },
    { label: 'Groups', icon: UsersRound }, { label: 'Marketplace', icon: Store },
    { label: 'Watch', icon: PlaySquare }, { label: 'Memories', icon: Sparkles },
    { label: 'Saved', icon: Bookmark }, { label: 'Events', icon: CalendarDays },
  ]

  return (
    <div className="min-h-screen bg-[#f0f2f5]">
      <header className="fixed inset-x-0 top-0 z-30 flex h-[68px] items-center justify-between border-b border-slate-200 bg-white px-4 shadow-sm">
        <div className="flex items-center gap-3">
          <button className="rounded-full p-2 hover:bg-slate-100 lg:hidden" onClick={() => setShowMore(!showMore)} aria-label="Open menu"><Menu size={23}/></button>
          <div className="text-[28px] font-extrabold tracking-tight text-[#1877f2] sm:text-[32px]">socialbook</div>
          <div className="hidden w-64 items-center gap-2 rounded-full bg-[#f0f2f5] px-4 py-3 md:flex">
            <Search size={19} className="text-slate-500"/>
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search SocialBook" className="w-full bg-transparent text-sm outline-none placeholder:text-slate-500"/>
          </div>
        </div>
        <nav className="hidden h-full items-center gap-2 md:flex">
          {[{label:'Home',icon:Home},{label:'Watch',icon:Video},{label:'Groups',icon:UsersRound},{label:'Friends',icon:Users}].map(({label,icon:Icon}) =>
            <button key={label} onClick={() => setActiveNav(label)} className={`flex h-full w-16 items-center justify-center border-b-[3px] transition ${activeNav === label ? 'border-[#1877f2] text-[#1877f2]' : 'border-transparent text-slate-500 hover:bg-slate-50'}`} aria-label={label}><Icon size={25}/></button>
          )}
        </nav>
        <div className="flex items-center gap-2 sm:gap-3">
          <button className="rounded-full bg-[#e4e6eb] p-2.5 hover:bg-slate-300" aria-label="Messages" onClick={() => setNotice('Messaging is a demo feature.')}><MessageCircle size={21}/></button>
          <button className="relative rounded-full bg-[#e4e6eb] p-2.5 hover:bg-slate-300" aria-label="Notifications" onClick={() => setNotice('You are all caught up!')}><Bell size={21}/><span className="absolute -right-1 -top-1 rounded-full bg-red-500 px-1.5 text-xs text-white">3</span></button>
          <img src={avatar(13)} alt="Your profile" className="h-10 w-10 rounded-full object-cover ring-2 ring-white"/>
        </div>
      </header>

      {notice && <div className="fixed left-1/2 top-[78px] z-50 -translate-x-1/2 rounded-xl bg-slate-900 px-4 py-3 text-sm text-white shadow-lg">{notice}</div>}

      <div className="mx-auto grid max-w-[1600px] grid-cols-1 gap-6 px-3 pb-10 pt-[88px] sm:px-5 lg:grid-cols-[250px_minmax(0,680px)_300px] xl:grid-cols-[280px_minmax(0,680px)_320px]">
        <aside className={`${showMore ? 'block' : 'hidden'} space-y-1 lg:sticky lg:top-[88px] lg:block lg:h-[calc(100vh-100px)] lg:overflow-y-auto`}>
          <div className="mb-3 flex items-center gap-3 rounded-xl p-3 font-semibold"><img src={avatar(13)} alt="" className="h-9 w-9 rounded-full"/> Abhi Arya</div>
          {navItems.map(({label, icon: Icon}) => <button key={label} onClick={() => {setActiveNav(label); setShowMore(false); if(label !== 'Home') setNotice(`${label} is a demo navigation section.`)}} className={`flex w-full items-center gap-4 rounded-xl px-3 py-3 text-left font-medium ${activeNav === label ? 'bg-blue-100 text-[#1877f2]' : 'hover:bg-slate-200'}`}><Icon size={23} className={activeNav === label ? 'text-[#1877f2]' : 'text-slate-500'}/>{label}</button>)}
          <div className="my-3 border-t border-slate-300"/>
          <p className="px-3 pb-2 text-sm font-semibold text-slate-500">Your shortcuts</p>
          {['Design Inspiration','Tech & AI','Travel Vibes','Fitness & Health'].map((item,i) => <button key={item} onClick={() => setNotice(`${item} shortcut selected.`)} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm hover:bg-slate-200"><span className={`flex h-9 w-9 items-center justify-center rounded-lg ${['bg-purple-100','bg-blue-100','bg-cyan-100','bg-pink-100'][i]}`}><Sparkles size={18}/></span>{item}</button>)}
          <p className="px-3 pt-4 text-xs leading-5 text-slate-500">Privacy · Terms · Advertising · Cookies · More</p>
        </aside>

        <main className="min-w-0 space-y-5">
          <section className="rounded-2xl bg-white p-3 shadow-sm">
            <div className="mb-3 flex items-center justify-between px-1"><h2 className="font-bold">Stories</h2><button className="text-sm font-semibold text-[#1877f2]" onClick={() => setNotice('All stories are shown in this demo.')}>See all</button></div>
            <div className="grid grid-cols-4 gap-2 sm:grid-cols-5">
              <button onClick={() => setNotice('Story creation is a demo feature.')} className="overflow-hidden rounded-xl border border-slate-100 text-center hover:bg-slate-50">
                <div className="relative h-28 bg-slate-100 sm:h-36"><img src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=300&auto=format&fit=crop&q=80" alt="" className="h-full w-full object-cover opacity-70"/><span className="absolute bottom-[-14px] left-1/2 flex h-9 w-9 -translate-x-1/2 items-center justify-center rounded-full border-4 border-white bg-[#1877f2] text-white"><Plus size={20}/></span></div><div className="px-1 pb-2 pt-5 text-xs font-semibold sm:text-sm">Create story</div>
              </button>
              {stories.map(s => <button key={s.name} onClick={() => setNotice(`${s.name}'s story opened in demo mode.`)} className="relative h-44 overflow-hidden rounded-xl text-left text-white sm:h-48"><img src={s.cover} alt="" className="absolute inset-0 h-full w-full object-cover"/><div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-black/70"/><img src={s.image} alt="" className="absolute left-2 top-2 h-9 w-9 rounded-full border-4 border-[#1877f2] object-cover"/><span className="absolute bottom-2 left-2 right-1 text-xs font-semibold sm:text-sm">{s.name}</span></button>)}
            </div>
          </section>

          <section className="rounded-2xl bg-white p-4 shadow-sm">
            <div className="flex gap-3">
              <img src={avatar(13)} alt="" className="h-11 w-11 rounded-full object-cover"/>
              <textarea value={draft} onChange={e => setDraft(e.target.value)} placeholder="What's on your mind, Abhi?" rows={2} className="min-h-[48px] flex-1 resize-y rounded-3xl bg-[#f0f2f5] px-5 py-3 outline-none focus:ring-2 focus:ring-blue-200"/>
            </div>
            <div className="my-3 border-t border-slate-200"/>
            <div className="flex flex-wrap items-center justify-around gap-2">
              <button onClick={() => setNotice('Live video is not connected in this demo.')} className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100"><Video className="text-red-500" size={21}/> <span className="hidden sm:inline">Live video</span></button>
              <button onClick={() => setNotice('Photo upload can be added with a backend.')} className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100"><Image className="text-green-600" size={21}/> Photo/video</button>
              <button onClick={() => setDraft(d => d + (d ? ' ' : '') + '😊')} className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100"><Smile className="text-amber-500" size={21}/> Feeling/activity</button>
            </div>
            <button onClick={publish} disabled={!draft.trim()} className="mt-3 w-full rounded-lg bg-[#1877f2] py-2.5 font-semibold text-white hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50">Post</button>
          </section>

          {visiblePosts.map(post => <article key={post.id} className="overflow-hidden rounded-2xl bg-white shadow-sm">
            <div className="flex items-start gap-3 px-4 pb-2 pt-4">
              <img src={post.avatar} alt="" className="h-11 w-11 rounded-full object-cover"/>
              <div className="min-w-0 flex-1"><div className="font-bold">{post.name}</div><div className="flex items-center gap-1 text-xs text-slate-500">{post.time} · <Globe2 size={12}/></div></div>
              <button onClick={() => setNotice('Post options opened in demo mode.')} className="rounded-full p-2 text-slate-500 hover:bg-slate-100" aria-label="More post options"><MoreHorizontal size={22}/></button>
            </div>
            <p className="whitespace-pre-line px-4 pb-3 text-[15px] leading-6">{post.text}</p>
            {post.image && <img src={post.image} alt="Post" className="max-h-[460px] w-full object-cover"/>}
            <div className="flex items-center justify-between px-4 py-3 text-sm text-slate-500">
              <div className="flex items-center gap-1.5"><span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#1877f2] text-white"><ThumbsUp size={12} fill="currentColor"/></span><span>{post.likes}</span></div>
              <div className="flex gap-3"><button onClick={() => setOpenComments(prev => ({...prev,[post.id]:!prev[post.id]}))}>{post.comments + (comments[post.id]?.length || 0)} comments</button><span>{post.shares} shares</span></div>
            </div>
            <div className="mx-4 border-t border-slate-200"/>
            <div className="grid grid-cols-3 gap-1 px-2 py-1.5">
              <button onClick={() => toggleLike(post.id)} className={`flex items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-semibold hover:bg-slate-100 ${post.liked ? 'text-[#1877f2]' : 'text-slate-600'}`}><ThumbsUp size={19} fill={post.liked ? 'currentColor' : 'none'}/> Like</button>
              <button onClick={() => setOpenComments(prev => ({...prev,[post.id]:!prev[post.id]}))} className="flex items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-semibold text-slate-600 hover:bg-slate-100"><MessageSquare size={19}/> Comment</button>
              <button onClick={() => {setPosts(prev => prev.map(p => p.id === post.id ? {...p, shares:p.shares+1} : p)); setNotice('Share counted in this demo.')}} className="flex items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-semibold text-slate-600 hover:bg-slate-100"><Share2 size={19}/> Share</button>
            </div>
            {openComments[post.id] && <div className="space-y-3 border-t border-slate-100 px-4 py-3">
              {(comments[post.id] || []).map((comment,i) => <div key={i} className="rounded-2xl bg-[#f0f2f5] px-4 py-2 text-sm">{comment}</div>)}
              <div className="flex gap-2"><input value={commentDrafts[post.id] || ''} onChange={e => setCommentDrafts(prev => ({...prev,[post.id]:e.target.value}))} onKeyDown={e => e.key === 'Enter' && addComment(post.id)} placeholder="Write a comment..." className="min-w-0 flex-1 rounded-full bg-[#f0f2f5] px-4 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-200"/><button onClick={() => addComment(post.id)} className="rounded-full bg-[#1877f2] p-2 text-white hover:bg-blue-700" aria-label="Send comment"><Send size={17}/></button></div>
            </div>}
          </article>)}
          {visiblePosts.length === 0 && <div className="rounded-2xl bg-white p-8 text-center text-slate-500">No posts match “{search}”. Try another search.</div>}
          <p className="pb-4 text-center text-xs text-slate-500">SocialBook is an original demo project — not affiliated with Facebook or Meta.</p>
        </main>

        <aside className="hidden space-y-4 lg:block">
          <section className="rounded-2xl bg-white p-4 shadow-sm">
            <div className="mb-4 flex items-center justify-between"><h2 className="font-bold">Friend requests</h2><button onClick={() => setNotice('No more friend requests in this demo.')} className="text-sm text-[#1877f2]">See all</button></div>
            {[{name:'Emma Wilson',img:avatar(47),mutual:'2 mutual friends'},{name:'Daniel Carter',img:avatar(12),mutual:'5 mutual friends'}].map(person => <div key={person.name} className="mb-4 flex gap-3 last:mb-0"><img src={person.img} alt="" className="h-14 w-14 rounded-full object-cover"/><div className="min-w-0 flex-1"><div className="font-semibold">{person.name}</div><div className="text-sm text-slate-500">{person.mutual}</div><div className="mt-2 flex gap-2"><button onClick={() => setNotice(`You confirmed ${person.name} in this demo.`)} className="flex-1 rounded-lg bg-[#1877f2] px-2 py-2 text-sm font-semibold text-white hover:bg-blue-700">Confirm</button><button onClick={() => setNotice(`Request from ${person.name} deleted in this demo.`)} className="flex-1 rounded-lg bg-slate-100 px-2 py-2 text-sm font-semibold hover:bg-slate-200">Delete</button></div></div></div>)}
          </section>
          <section className="rounded-2xl bg-white p-4 shadow-sm">
            <div className="mb-3 flex items-center justify-between"><h2 className="font-bold">Sponsored</h2><button onClick={() => setNotice('Sponsored content settings are not connected.')} className="text-sm text-[#1877f2]">See all</button></div>
            <div className="flex gap-3"><img src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=240&auto=format&fit=crop&q=80" alt="" className="h-24 w-24 rounded-xl object-cover"/><div><div className="font-semibold">Build your future</div><p className="mt-1 text-sm text-slate-500">Learn new skills with online courses.</p><span className="mt-2 block text-xs text-slate-400">learn.example</span></div></div>
          </section>
          <section className="rounded-2xl bg-white p-4 shadow-sm">
            <div className="mb-3 flex items-center justify-between"><h2 className="font-bold">Contacts</h2><button aria-label="Search contacts" onClick={() => setNotice('Contact search is a demo feature.')}><Search size={19} className="text-slate-500"/></button></div>
            {stories.map(s => <button key={s.name} onClick={() => setNotice(`Chat with ${s.name} is not connected yet.`)} className="flex w-full items-center gap-3 rounded-lg px-1 py-2 text-sm font-medium hover:bg-slate-50"><span className="relative"><img src={s.image} alt="" className="h-9 w-9 rounded-full object-cover"/><span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-white bg-green-500"/></span>{s.name}</button>)}
          </section>
        </aside>
      </div>
    </div>
  )
}

export default App
